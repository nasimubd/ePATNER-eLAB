<?php

return [
    App\Providers\AppServiceProvider::class,
    Intervention\Image\ImageServiceProvider::class,
];
